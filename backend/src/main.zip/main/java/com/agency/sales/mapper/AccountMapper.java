package com.agency.sales.mapper;

import java.util.Optional;
import org.apache.ibatis.annotations.Mapper;
import com.agency.sales.domain.Account;

@Mapper
public interface AccountMapper {
  Optional<Account> findByUsername(String username);
  void insert(Account account);
}
