package com.agency.sales.service;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.agency.sales.domain.Account;
import com.agency.sales.mapper.AccountMapper;

@Service
public class CustomUserDetailsService implements UserDetailsService {
  private final AccountMapper accountMapper;

  public CustomUserDetailsService(AccountMapper accountMapper) {
    this.accountMapper = accountMapper;
  }

  @Override
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    Account account = accountMapper.findByUsername(username)
        .orElseThrow(() -> new UsernameNotFoundException("Account not found: " + username));

    return (
      User
        .withUsername(account.getUsername())
        .password(account.getPassword())
        .roles(account.getRole().name().replace("ROLE_", ""))
        .build()
    );
  }

}
