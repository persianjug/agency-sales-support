package com.agency.sales.domain;

import lombok.Getter;

@Getter
public enum Role {
  ROLE_ADMIN("管理者"),
  ROLE_USER("一般ユーザー");

  private final String description;

  Role(String description) {
    this.description = description;
  }
}
