package com.agency.sales.config;

import com.agency.sales.dto.ErrorResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;

@RestControllerAdvice
public class GlobalExceptionHandler {

  // 1. 認証失敗系エラー（401 Unauthorized）
  @ExceptionHandler({ BadCredentialsException.class, UsernameNotFoundException.class })
  public ResponseEntity<ErrorResponse> handleAuthException() {
    return createErrorResponse(HttpStatus.UNAUTHORIZED, "ユーザー名またはパスワードが正しくありません。");
  }

  // 2. その他の想定外エラー（500 Internal Server Error）
  @ExceptionHandler(Exception.class)
  public ResponseEntity<ErrorResponse> handleGeneralException(Exception e) {
    return createErrorResponse(
        HttpStatus.INTERNAL_SERVER_ERROR,
        "システムエラーが発生しました。時間をおいて再度お試しください。");
  }

  // レスポンス生成の共通メソッド
  private ResponseEntity<ErrorResponse> createErrorResponse(HttpStatus status, String message) {
    ErrorResponse response = ErrorResponse.builder()
        .timestamp(Instant.now())
        .status(status.value())
        .error(status.getReasonPhrase().toUpperCase().replace(" ", "_"))
        .message(message)
        .build();

    return ResponseEntity.status(status).body(response);
  }
}