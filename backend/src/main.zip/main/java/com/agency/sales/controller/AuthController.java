package com.agency.sales.controller;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.agency.sales.domain.Account;
import com.agency.sales.domain.Role;
import com.agency.sales.dto.AuthReponse;
import com.agency.sales.dto.AuthRequest;
import com.agency.sales.mapper.AccountMapper;
import com.agency.sales.service.AuthService;
import org.springframework.web.bind.annotation.PostMapping;


@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {
  private final AuthService authService;

  public AuthController(AuthService authService) {
    this.authService = authService;
  }
 
  @PostMapping("/login")
  public ResponseEntity<AuthReponse> login(@RequestBody AuthRequest request) {
    AuthReponse reponse = authService.login(request);
    return ResponseEntity.ok(reponse);
  }

  // テストユーザー自動投入（起動時）
  @Bean
  public CommandLineRunner initDatabase(AccountMapper accountMapper, PasswordEncoder passwordEncoder) {
    return args -> {
      if (accountMapper.findByUsername("admin").isEmpty()) {
        Account admin = Account.builder()
            .username("admin")
            .password(passwordEncoder.encode("password123"))
            .role(Role.ROLE_ADMIN)
            .build();
        accountMapper.insert(admin);
      }
    };
  }

}