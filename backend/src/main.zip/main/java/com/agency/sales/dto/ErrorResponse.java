package com.agency.sales.dto;

import java.time.Instant;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ErrorResponse {
  private Instant timestamp; // エラー発生時刻 (ISO-8601)
  private int status; // HTTPステータスコード (例: 401, 400, 500)
  private String error; // エラー種別 (例: "UNAUTHORIZED")
  private String message; // ユーザーやフロント向けのエラー詳細メッセージ
}
