package com.agency.sales.service;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.agency.sales.dto.AuthReponse;
import com.agency.sales.dto.AuthRequest;
import com.agency.sales.security.JwtTokenProvider;

@Service
public class AuthService {
  private final AuthenticationManager authenticationManager;
  private final JwtTokenProvider tokenProvider;

  public AuthService(AuthenticationManager authenticationManager, JwtTokenProvider tokenProvider) {
    this.authenticationManager = authenticationManager;
    this.tokenProvider = tokenProvider;
  }

  public AuthReponse login(AuthRequest request) {
    Authentication authentication = authenticationManager.authenticate(
        new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));

    String role = authentication.getAuthorities().iterator().next().getAuthority();
    String token = tokenProvider.generateToken(request.getUsername(), role);

    return new AuthReponse(token);
  }

}
